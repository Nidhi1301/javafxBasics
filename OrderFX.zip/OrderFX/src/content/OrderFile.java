 /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package content;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.StringTokenizer;


public class OrderFile {

    public static ArrayList<Order> getData()
            throws IOException {

        ArrayList<Order> orderList = new ArrayList<>();
       
        FileReader fr = new FileReader("Order.dat");
        BufferedReader br = new BufferedReader(fr);
                
            String line = br.readLine();
            while (line != null) {
                StringTokenizer st = new StringTokenizer(line, ",");
                String orderId = st.nextToken();
                String customerId = st.nextToken();
                String product = st.nextToken();
                String shipping = st.nextToken();
                
                Order one = new Order(orderId);
                one.setCustomerId(customerId);
                one.setProduct(product);
                one.setShipping(shipping);
                
                orderList.add(one);
                
                line = br.readLine();
            }
        br.close();
        fr.close();

        return orderList;
    }

    
    public static void setData(ArrayList<Order> orderList)
            throws IOException {

        FileWriter fw = new FileWriter("Order.dat"); 
        BufferedWriter bw = new BufferedWriter(fw) ;
            
            for (int i = 0; i < orderList.size(); i++) {
                Order one = orderList.get(i);
                
                String data = (one.getCustomerId() + "," + one.getOrderId() + ","
                        + one.getProduct() + "," + one.getShipping());
                
                bw.write(data);
                bw.newLine();
                
            }
        bw.close();
        fw.close();

    }

    
   
}
