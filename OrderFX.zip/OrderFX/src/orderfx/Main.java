/*
 * 
 *Name - Nidhi Nidhi
 * Student id - 991563808
 * Assignment - 3
 * Date - March 8, 2020
 */
package orderfx;

import content.Order;
import content.OrderFile;
import static content.OrderFile.getData;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;


public class Main extends Application {

//    
  private final Label lblCustomerId = new Label("Customer Id:");
   private TextField txtCustomerId = new TextField();
   private final Label lblOrderId = new Label("Order Id");
  private final TextField txtOrderId = new TextField();
  private final Label lblProduct = new Label("Product");
   private final TextField txtProduct = new TextField();
   private final Label lblShipping = new Label("Shipping Method :");
 private final TextField txtShipping = new TextField();
    private Button btnnext = new Button("Next Button");
        private Button btnprevious = new Button("Previous Button");
            private Button btnlast = new Button("Last Button");
    private Button btnfirst = new Button("First Button");
private Button btnupdate =  new  Button("Update    ");

    private String orderId;
    
    @Override
    public void start(Stage primaryStage) throws IOException {
        
        btnnext.setOnAction(e->  {
    
    });
       
      btnprevious.setOnAction(e->{
      
      });
      btnfirst.setOnAction(e->{
      
      
      });
      btnlast.setOnAction(e->{
      });  
      try{
    ArrayList<Order> orderList = OrderFile.getData();
   // Order one = new Order(orderId);
      addScene(orderList.get(0));
      }catch(IOException e){
      
          System.out.println(e);
      }       
        
       
        Scene scene = new Scene(addPane(), 300, 250);
        primaryStage.setTitle("Order Page");
       primaryStage.setScene(scene);
        primaryStage.show();
    }
   private void addScene(Order one) {
       
      String orderId = one.getOrderId();
      txtOrderId.setText(orderId);
      String customerId  =  one.getCustomerId();
      txtCustomerId.setText(customerId);
      String product =  one.getProduct();
      txtProduct.setText(product);
      String shipping =   one.getShipping();
      txtShipping.setText(shipping);
    
   }
//    
    private GridPane addPane() {

     GridPane pane = new GridPane();
        pane.add(lblOrderId, 0, 1);
     pane.add(txtOrderId, 1, 0);
     pane.add(lblCustomerId, 0, 2);
     pane.add(txtCustomerId, 1, 2);
  
     pane.add(lblProduct, 0, 3);
     pane.add(txtProduct, 1, 3);
     pane.add(lblShipping, 0, 4);
       pane.add(txtShipping, 1, 4);
      pane.add(btnnext, 1,5);
      
      return pane;
   }

   
    public static void main(String[] args) {
        launch(args);
     
    }

   

}
